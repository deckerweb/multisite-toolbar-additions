Liberation Sans 2.1.5, Regular and Bold.

Official source: https://github.com/liberationfonts/liberation-fonts/releases/tag/2.1.5
Archive: https://github.com/liberationfonts/liberation-fonts/files/7261482/liberation-fonts-ttf-2.1.5.tar.gz

Original unmodified font files. SIL Open Font License 1.1; see LICENSE.
No font files are included in the installable plugin package.
