<?php
// Disposable test fixture.
